package pages;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class login extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtemail;
    private JTextField txtpassword;
    private JLabel lblPassword;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                login frame = new login();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public login() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 864, 564);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        txtemail = new JTextField();
        txtemail.setBounds(258, 143, 241, 29);
        contentPane.add(txtemail);
        txtemail.setColumns(10);

        txtpassword = new JTextField();
        txtpassword.setBounds(257, 200, 242, 29);
        contentPane.add(txtpassword);
        txtpassword.setColumns(10);

        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String email = txtemail.getText();
                String password = txtpassword.getText();

                if (authenticateUser(email, password)) {
                    txtpassword.setText(null);
                    txtemail.setText(null);

                    if (email.equals("admin@gmail.com")) {
                        new admin().setVisible(true);
                    } else if (email.equals("faculty@gmail.com")) {
                        new faculty().setVisible(true);
                    } else {
                        new student().setVisible(true);
                    }
                    SwingUtilities.getWindowAncestor(loginButton).dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid Login Details", "Login Error", JOptionPane.ERROR_MESSAGE);
                    txtpassword.setText(null);
                    txtemail.setText(null);
                }
            }
        });
        loginButton.setBounds(332, 271, 89, 23);
        contentPane.add(loginButton);

        JLabel lblNewLabel = new JLabel("Email");
        lblNewLabel.setBounds(258, 118, 209, 14);
        contentPane.add(lblNewLabel);

        lblPassword = new JLabel("Password");
        lblPassword.setBounds(258, 183, 82, 14);
        contentPane.add(lblPassword);
    }

    private boolean authenticateUser(String email, String password) {
        boolean isAuthenticated = false;
        try (Connection con = database.getConnection()) {
            String query = "SELECT * FROM user WHERE email = ? AND pass = ?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, email);
            pst.setString(2, password);
            ResultSet rs = pst.executeQuery();
            isAuthenticated = rs.next();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return isAuthenticated;
    }
}
